export const extractTextFromFile = async (file: File): Promise<string> => {
  const extension = file.name.split('.').pop()?.toLowerCase();

  try {
    if (extension === 'txt') {
      return await file.text();
    } else if (extension === 'pdf') {
      return await extractPdfText(file);
    } else if (extension === 'docx' || extension === 'doc') {
      return await extractDocxText(file);
    } else {
      throw new Error('Unsupported file type. Please upload PDF, DOCX, or TXT.');
    }
  } catch (error) {
    console.error('Error parsing file:', error);
    throw new Error('Failed to parse resume content. Please ensure the file is not corrupted.');
  }
};

const extractPdfText = async (file: File): Promise<string> => {
  if (!window.pdfjsLib) {
    throw new Error('PDF library not loaded');
  }
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await window.pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let fullText = '';

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const pageText = textContent.items.map((item: any) => item.str).join(' ');
    fullText += pageText + '\n';
  }
  return fullText;
};

const extractDocxText = async (file: File): Promise<string> => {
  if (!window.mammoth) {
    throw new Error('DOCX library not loaded');
  }
  const arrayBuffer = await file.arrayBuffer();
  const result = await window.mammoth.extractRawText({ arrayBuffer });
  return result.value;
};