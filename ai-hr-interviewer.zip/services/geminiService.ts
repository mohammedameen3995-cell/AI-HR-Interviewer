import { GoogleGenAI, Type } from "@google/genai";
import { FeedbackData, TranscriptItem } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateFeedback = async (
  resumeText: string,
  transcript: TranscriptItem[]
): Promise<FeedbackData> => {
  
  const conversationHistory = transcript.map(t => `${t.role.toUpperCase()}: ${t.text}`).join('\n');

  const prompt = `
    You are an expert HR Consultant. 
    Analyze the following Candidate Resume and Interview Transcript to provide a detailed feedback report.

    CANDIDATE RESUME:
    ${resumeText.substring(0, 10000)}

    INTERVIEW TRANSCRIPT:
    ${conversationHistory.substring(0, 20000)}

    Provide the output in strict JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            resumeAnalysis: { type: Type.STRING, description: "Feedback on resume formatting, clarity, and impact." },
            interviewFeedback: { type: Type.STRING, description: "Feedback on how the candidate performed in the interview (communication, confidence)." },
            skillsGap: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "List of missing or weak skills relative to the resume claims." 
            },
            projectSuggestions: { type: Type.STRING, description: "Suggestions to improve project descriptions or talk tracks." },
            overallScore: { type: Type.INTEGER, description: "Score from 1-100." }
          },
          required: ["resumeAnalysis", "interviewFeedback", "skillsGap", "projectSuggestions", "overallScore"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as FeedbackData;
    }
    throw new Error("No response text from Gemini");
  } catch (error) {
    console.error("Feedback generation error:", error);
    // Return a fallback in case of JSON parse error or API failure
    return {
      resumeAnalysis: "Could not generate analysis.",
      interviewFeedback: "Could not generate feedback.",
      skillsGap: ["N/A"],
      projectSuggestions: "N/A",
      overallScore: 0
    };
  }
};
