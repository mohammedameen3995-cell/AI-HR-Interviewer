import React, { useEffect, useState } from 'react';
import { FeedbackData } from '../types';

interface FeedbackScreenProps {
  data: FeedbackData;
  onRestart: () => void;
}

export const FeedbackScreen: React.FC<FeedbackScreenProps> = ({ data, onRestart }) => {
  const [animatedScore, setAnimatedScore] = useState(0);

  useEffect(() => {
    let start = 0;
    const end = data.overallScore;
    if (start === end) return;

    const timer = setInterval(() => {
      start += 1;
      setAnimatedScore(start);
      if (start >= end) clearInterval(timer);
    }, 20);

    return () => clearInterval(timer);
  }, [data.overallScore]);

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 60) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <div className="max-w-4xl mx-auto p-4 pb-12">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Interview Feedback Report</h2>
        <p className="text-slate-600">Here is a detailed breakdown of your performance and resume.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Score Card */}
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-100 flex flex-col items-center justify-center col-span-1 md:col-span-1">
          <h3 className="text-lg font-semibold text-slate-500 mb-4">Overall Score</h3>
          <div className={`text-6xl font-bold ${getScoreColor(animatedScore)}`}>
            {animatedScore}
          </div>
          <span className="text-slate-400 text-sm mt-2">out of 100</span>
        </div>

        {/* Quick Stats */}
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-100 col-span-1 md:col-span-2 flex flex-col justify-center">
            <h3 className="text-lg font-semibold text-slate-800 mb-3">Summary</h3>
            <p className="text-slate-600 italic">"{data.interviewFeedback.substring(0, 150)}..."</p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* Resume Analysis */}
        <div className="bg-white p-6 rounded-2xl shadow-md border-l-4 border-blue-500">
            <div className="flex items-center mb-4">
                <div className="bg-blue-100 p-2 rounded-lg mr-3">
                    <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                </div>
                <h3 className="text-xl font-bold text-slate-800">Resume Analysis</h3>
            </div>
            <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{data.resumeAnalysis}</p>
        </div>

        {/* Communication Feedback */}
        <div className="bg-white p-6 rounded-2xl shadow-md border-l-4 border-purple-500">
            <div className="flex items-center mb-4">
                <div className="bg-purple-100 p-2 rounded-lg mr-3">
                    <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
                </div>
                <h3 className="text-xl font-bold text-slate-800">Communication Skills</h3>
            </div>
            <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{data.interviewFeedback}</p>
        </div>

        {/* Skills Gaps */}
        <div className="bg-white p-6 rounded-2xl shadow-md border-l-4 border-orange-500">
            <div className="flex items-center mb-4">
                <div className="bg-orange-100 p-2 rounded-lg mr-3">
                    <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                </div>
                <h3 className="text-xl font-bold text-slate-800">Identified Gaps</h3>
            </div>
             <ul className="list-disc list-inside space-y-2">
                {data.skillsGap.map((gap, i) => (
                    <li key={i} className="text-slate-700">{gap}</li>
                ))}
            </ul>
        </div>
        
        {/* Project Suggestions */}
        <div className="bg-white p-6 rounded-2xl shadow-md border-l-4 border-green-500">
             <div className="flex items-center mb-4">
                <div className="bg-green-100 p-2 rounded-lg mr-3">
                    <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>
                </div>
                <h3 className="text-xl font-bold text-slate-800">Project Improvements</h3>
            </div>
            <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{data.projectSuggestions}</p>
        </div>
      </div>

      <div className="mt-12 text-center">
        <button 
            onClick={onRestart}
            className="px-8 py-3 bg-slate-800 text-white rounded-full font-semibold hover:bg-slate-700 transition-colors shadow-lg"
        >
            Start New Interview
        </button>
      </div>
    </div>
  );
};