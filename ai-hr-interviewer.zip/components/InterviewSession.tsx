import React, { useEffect, useState } from 'react';
import { useLiveInterview } from '../hooks/useLiveInterview';
import { TranscriptItem } from '../types';

interface InterviewSessionProps {
  resumeText: string;
  onEndInterview: (transcript: TranscriptItem[]) => void;
}

export const InterviewSession: React.FC<InterviewSessionProps> = ({ resumeText, onEndInterview }) => {
  const [transcript, setTranscript] = React.useState<TranscriptItem[]>([]);
  const [sessionStarted, setSessionStarted] = useState(false);
  
  const handleTranscriptUpdate = (item: TranscriptItem) => {
    setTranscript(prev => [...prev, item]);
  };

  const handleDisconnect = () => {
    // When live session ends (unexpectedly or manually), we trigger the end flow
    // We do NOT call onEndInterview here automatically to avoid loops, 
    // instead the End button triggers the manual finish.
  };

  const { connect, disconnect, isConnected, isTalking, volume, isMuted, toggleMute } = useLiveInterview({
    resumeText,
    onTranscriptUpdate: handleTranscriptUpdate,
    onDisconnect: handleDisconnect
  });

  const handleStartSession = () => {
    setSessionStarted(true);
    connect();
  };

  const handleFinish = () => {
    disconnect();
    onEndInterview(transcript);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
        disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!sessionStarted) {
    return (
      <div className="flex flex-col items-center justify-center h-full max-w-xl mx-auto p-6 animate-fade-in text-center">
         <div className="bg-white p-8 rounded-3xl shadow-xl w-full">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">Initialize Microphone</h2>
            <p className="text-slate-600 mb-8">
                Click below to enable voice input and begin the interview session.
            </p>
            <button 
              onClick={handleStartSession}
              className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl hover:bg-blue-700 transition-all transform hover:scale-[1.02] shadow-lg hover:shadow-blue-200"
            >
              Start Voice Session
            </button>
         </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto p-4">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Interview in Progress</h2>
          <p className="text-slate-500 text-sm">Speak clearly. The AI is listening.</p>
        </div>
        <div className="bg-red-50 text-red-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider flex items-center">
            <span className="w-2 h-2 bg-red-600 rounded-full mr-2 animate-pulse"></span>
            Live
        </div>
      </div>

      {/* Main Visualizer Area */}
      <div className="flex-1 bg-slate-900 rounded-3xl shadow-2xl relative overflow-hidden flex flex-col items-center justify-center min-h-[400px]">
        
        {/* Connection Status Overlay */}
        {!isConnected && (
            <div className="absolute inset-0 bg-black/50 z-20 flex items-center justify-center backdrop-blur-sm">
                <div className="text-white flex flex-col items-center">
                     <svg className="animate-spin h-8 w-8 mb-3" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>Connecting to HR AI...</span>
                </div>
            </div>
        )}

        {/* AI Avatar / Orb */}
        <div className="relative z-10 mb-8">
            <div className={`w-32 h-32 rounded-full bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center transition-transform duration-100 ${isTalking ? 'animate-pulse-ring' : ''}`}
                 style={{ transform: `scale(${1 + (volume / 255) * 0.5})` }}
            >
                <svg className="w-16 h-16 text-white opacity-90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
            </div>
        </div>

        {/* Status Text */}
        <div className="text-white text-lg font-medium opacity-90 text-center">
            {isTalking ? "Interviewer is speaking..." : (isMuted ? "Microphone muted" : "Listening to you...")}
        </div>
        
        {/* Waveform / Volume Bar Visualizer */}
        <div className="flex items-center justify-center space-x-1 mt-8 h-12">
            {[...Array(12)].map((_, i) => (
                <div 
                    key={i}
                    className="w-2 bg-blue-400 rounded-full transition-all duration-75"
                    style={{ 
                        height: `${Math.max(4, (volume / 255) * 100 * (Math.random() + 0.5))}px`,
                        opacity: isTalking ? 0.3 : 1 
                    }}
                ></div>
            ))}
        </div>

        {/* Controls Overlay Bottom */}
        <div className="absolute bottom-6 left-0 right-0 flex justify-center items-center space-x-6 z-30">
            {/* Mute/Unmute Button */}
            <button 
                onClick={toggleMute}
                className={`p-4 rounded-full transition-all duration-200 ${
                    isMuted 
                    ? 'bg-red-500/80 hover:bg-red-500 text-white' 
                    : 'bg-slate-700/50 hover:bg-slate-700 text-white'
                } backdrop-blur-md`}
                title={isMuted ? "Unmute Microphone" : "Mute Microphone"}
            >
                {isMuted ? (
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3l18 18" />
                    </svg>
                ) : (
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                    </svg>
                )}
            </button>

             {/* End Call Button */}
             <button 
                onClick={handleFinish}
                className="p-4 rounded-full bg-red-600 hover:bg-red-700 text-white transition-all shadow-lg hover:shadow-red-500/30 backdrop-blur-md"
                title="End Interview"
            >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 8l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M5 3a2 2 0 00-2 2v1c0 8.284 6.716 15 15 15h1a2 2 0 002-2v-3.28a1 1 0 00-.684-.948l-4.493-1.498a1 1 0 00-1.21.502l-1.13 2.257a11.042 11.042 0 01-5.516-5.517l2.257-1.128a1 1 0 00.502-1.21L9.228 3.683A1 1 0 008.279 3H5z" />
                </svg>
            </button>
        </div>
      </div>

      {/* Live Transcript Preview */}
      <div className="mt-6 h-48 bg-white rounded-xl border border-slate-200 p-4 overflow-y-auto shadow-inner">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Live Transcript</h3>
        {transcript.length === 0 && <p className="text-slate-400 text-sm italic">Conversation will appear here...</p>}
        {transcript.map((t, idx) => (
            <div key={idx} className={`mb-2 text-sm ${t.role === 'model' ? 'text-blue-600' : 'text-slate-700'}`}>
                <span className="font-bold mr-2">{t.role === 'model' ? 'HR:' : 'You:'}</span>
                {t.text}
            </div>
        ))}
      </div>
    </div>
  );
};