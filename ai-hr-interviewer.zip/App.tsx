import React, { useState } from 'react';
import { ResumeUpload } from './components/ResumeUpload';
import { InterviewSession } from './components/InterviewSession';
import { FeedbackScreen } from './components/FeedbackScreen';
import { AppState, ResumeData, FeedbackData, TranscriptItem } from './types';
import { generateFeedback } from './services/geminiService';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.UPLOAD);
  const [resumeData, setResumeData] = useState<ResumeData | null>(null);
  const [feedbackData, setFeedbackData] = useState<FeedbackData | null>(null);

  const handleResumeUpload = (data: ResumeData) => {
    setResumeData(data);
    setAppState(AppState.INTERVIEW_READY);
  };

  const startInterview = () => {
    setAppState(AppState.INTERVIEWING);
  };

  const handleEndInterview = async (transcript: TranscriptItem[]) => {
    if (!resumeData) return;
    
    setAppState(AppState.FEEDBACK_LOADING);
    
    // In a real scenario, we might want to ensure we have enough transcript
    // If the transcript is empty, provide generic feedback or ask to retry.
    if (transcript.length === 0) {
        // Mock a tiny transcript if none exists just to show UI (or handle error)
        transcript.push({ role: 'model', text: 'Hello' });
        transcript.push({ role: 'user', text: 'Hi' });
    }

    try {
      const feedback = await generateFeedback(resumeData.text, transcript);
      setFeedbackData(feedback);
      setAppState(AppState.FEEDBACK);
    } catch (e) {
      console.error(e);
      setAppState(AppState.ERROR);
    }
  };

  const handleRestart = () => {
    setResumeData(null);
    setFeedbackData(null);
    setAppState(AppState.UPLOAD);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans">
      {/* Navbar */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <svg className="h-8 w-8 text-blue-600 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              <span className="font-bold text-xl text-slate-800">AI Recruiter</span>
            </div>
            <div className="flex items-center">
                {appState !== AppState.UPLOAD && (
                    <button onClick={handleRestart} className="text-sm text-slate-500 hover:text-slate-800">Restart</button>
                )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-grow flex flex-col relative">
        {appState === AppState.UPLOAD && (
          <div className="flex-grow flex flex-col justify-center">
            <ResumeUpload onUploadComplete={handleResumeUpload} />
          </div>
        )}

        {appState === AppState.INTERVIEW_READY && (
           <div className="flex-grow flex flex-col items-center justify-center p-6 text-center animate-fade-in">
              <div className="bg-white p-8 rounded-3xl shadow-xl max-w-lg w-full">
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                  </div>
                  <h2 className="text-2xl font-bold text-slate-800 mb-2">Resume Analyzed!</h2>
                  <p className="text-slate-600 mb-8">
                      Your resume has been processed. The AI interviewer is ready to start the session. 
                      Make sure your microphone is working and you are in a quiet place.
                  </p>
                  <button 
                    onClick={startInterview}
                    className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl hover:bg-blue-700 transition-all transform hover:scale-[1.02] shadow-lg hover:shadow-blue-200"
                  >
                    Start Interview
                  </button>
              </div>
           </div>
        )}

        {appState === AppState.INTERVIEWING && resumeData && (
          <InterviewSession resumeText={resumeData.text} onEndInterview={handleEndInterview} />
        )}

        {appState === AppState.FEEDBACK_LOADING && (
          <div className="flex-grow flex flex-col items-center justify-center">
             <div className="flex flex-col items-center space-y-4">
                <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
                <h2 className="text-xl font-semibold text-slate-700">Generating Feedback...</h2>
                <p className="text-slate-500">Compiling your interview performance report.</p>
             </div>
          </div>
        )}

        {appState === AppState.FEEDBACK && feedbackData && (
          <FeedbackScreen data={feedbackData} onRestart={handleRestart} />
        )}

        {appState === AppState.ERROR && (
            <div className="flex-grow flex flex-col items-center justify-center p-6">
                <div className="text-red-500 text-xl font-bold mb-4">Something went wrong.</div>
                <button onClick={handleRestart} className="text-blue-600 underline">Try Again</button>
            </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-50 border-t border-slate-200 py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-400 text-sm">
          &copy; {new Date().getFullYear()} AI HR Interviewer. Powered by Google Gemini 2.0.
        </div>
      </footer>
    </div>
  );
};

export default App;