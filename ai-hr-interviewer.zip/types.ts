export enum AppState {
  UPLOAD = 'UPLOAD',
  ANALYZING = 'ANALYZING',
  INTERVIEW_READY = 'INTERVIEW_READY',
  INTERVIEWING = 'INTERVIEWING',
  FEEDBACK_LOADING = 'FEEDBACK_LOADING',
  FEEDBACK = 'FEEDBACK',
  ERROR = 'ERROR'
}

export interface ResumeData {
  fileName: string;
  text: string;
}

export interface FeedbackData {
  resumeAnalysis: string;
  interviewFeedback: string;
  skillsGap: string[];
  projectSuggestions: string;
  overallScore: number;
}

export interface TranscriptItem {
  role: 'user' | 'model';
  text: string;
}

// Global declaration for external libraries loaded via CDN
declare global {
  interface Window {
    pdfjsLib: any;
    mammoth: any;
  }
}