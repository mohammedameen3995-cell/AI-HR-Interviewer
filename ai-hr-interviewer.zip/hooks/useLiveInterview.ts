import { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { base64ToUint8Array, decodeAudioData, createPcmBlob } from '../utils/audioUtils';
import { TranscriptItem } from '../types';

interface UseLiveInterviewProps {
  resumeText: string;
  onTranscriptUpdate: (item: TranscriptItem) => void;
  onDisconnect: () => void;
}

export const useLiveInterview = ({ resumeText, onTranscriptUpdate, onDisconnect }: UseLiveInterviewProps) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isTalking, setIsTalking] = useState(false);
  const [volume, setVolume] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputContextRef = useRef<AudioContext | null>(null);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const currentInputTranscription = useRef<string>('');
  const currentOutputTranscription = useRef<string>('');
  const analyserRef = useRef<AnalyserNode | null>(null);
  const isMutedRef = useRef(false);
  
  // Cleanup function
  const cleanup = useCallback(() => {
    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(session => session.close()).catch(() => {});
      sessionPromiseRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    if (inputContextRef.current) {
      inputContextRef.current.close();
      inputContextRef.current = null;
    }
    setIsConnected(false);
    setIsTalking(false);
    onDisconnect();
  }, [onDisconnect]);

  const toggleMute = useCallback(() => {
    const nextState = !isMutedRef.current;
    isMutedRef.current = nextState;
    setIsMuted(nextState);
  }, []);

  const connect = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Initialize Audio Contexts
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const inputCtx = new AudioContextClass({ sampleRate: 16000 });
      const outputCtx = new AudioContextClass({ sampleRate: 24000 });
      
      inputContextRef.current = inputCtx;
      audioContextRef.current = outputCtx;

      // Setup Volume Visualizer
      analyserRef.current = outputCtx.createAnalyser();
      analyserRef.current.fftSize = 256;
      analyserRef.current.smoothingTimeConstant = 0.5;

      // Input Stream Setup
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const source = inputCtx.createMediaStreamSource(stream);
      const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
      
      scriptProcessor.onaudioprocess = (e) => {
        if (isMutedRef.current) return;

        const inputData = e.inputBuffer.getChannelData(0);
        const pcmBlob = createPcmBlob(inputData);
        
        if (sessionPromiseRef.current) {
          sessionPromiseRef.current.then(session => {
            session.sendRealtimeInput({ media: pcmBlob });
          });
        }
      };

      source.connect(scriptProcessor);
      scriptProcessor.connect(inputCtx.destination);

      // Gemini Live Connection
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            console.log('Gemini Live Connected');
            setIsConnected(true);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Transcriptions
            if (message.serverContent?.outputTranscription) {
               const text = message.serverContent.outputTranscription.text;
               currentOutputTranscription.current += text;
            } else if (message.serverContent?.inputTranscription) {
               const text = message.serverContent.inputTranscription.text;
               currentInputTranscription.current += text;
            }

            if (message.serverContent?.turnComplete) {
              const userText = currentInputTranscription.current.trim();
              const modelText = currentOutputTranscription.current.trim();
              
              if (userText) onTranscriptUpdate({ role: 'user', text: userText });
              if (modelText) onTranscriptUpdate({ role: 'model', text: modelText });

              currentInputTranscription.current = '';
              currentOutputTranscription.current = '';
              setIsTalking(false);
            }

            // Handle Audio Output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputCtx) {
              setIsTalking(true);
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              
              const audioBuffer = await decodeAudioData(
                base64ToUint8Array(base64Audio),
                outputCtx,
                24000,
                1
              );
              
              const bufferSource = outputCtx.createBufferSource();
              bufferSource.buffer = audioBuffer;
              bufferSource.connect(analyserRef.current!); // Connect to analyser
              analyserRef.current!.connect(outputCtx.destination); // Connect to speakers
              
              bufferSource.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              
              bufferSource.onended = () => {
                // Approximate "stop talking" logic if needed finely grained
              };
            }
          },
          onclose: () => {
            console.log('Gemini Live Closed');
            cleanup();
          },
          onerror: (err) => {
            console.error('Gemini Live Error', err);
            cleanup();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: { model: "gemini-2.5-flash" }, // Enable input transcription
          outputAudioTranscription: { model: "gemini-2.5-flash" }, // Enable output transcription
          systemInstruction: `You are a professional, polite, and insightful HR Interviewer. 
          Your goal is to interview a candidate based on the resume provided below.
          
          Resume Content:
          ${resumeText}
          
          Guidelines:
          1. Start by briefly introducing yourself as the Hiring Manager and asking the candidate to introduce themselves.
          2. Ask one question at a time. Wait for their response.
          3. Ask clarifying questions about their specific projects and skills mentioned in the resume.
          4. Evaluate their communication skills and technical depth.
          5. Keep your responses concise (under 2 sentences usually) to let the candidate speak more.
          6. If the candidate struggles, provide a gentle hint or move to the next question.
          7. Be conversational and natural.
          `,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
          }
        }
      });
      
      sessionPromiseRef.current = sessionPromise;

    } catch (error) {
      console.error("Failed to connect live session:", error);
      cleanup();
    }
  };

  // Visualizer loop
  useEffect(() => {
    let animationFrameId: number;
    
    const updateVolume = () => {
      if (analyserRef.current) {
        const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
        analyserRef.current.getByteFrequencyData(dataArray);
        
        // Calculate average volume
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        setVolume(avg); // 0-255
      }
      animationFrameId = requestAnimationFrame(updateVolume);
    };
    
    updateVolume();
    return () => cancelAnimationFrame(animationFrameId);
  }, []);

  return { connect, disconnect: cleanup, isConnected, isTalking, volume, isMuted, toggleMute };
};